package code.src.Form.FormF2.interfaces;

import code.src.interfaces.IForm;

public interface IFormF2 extends IForm {
}
