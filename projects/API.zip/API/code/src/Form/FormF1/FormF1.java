package code.src.Form.FormF1;

import code.src.BuildingBlocks.Init.Initiator_F1;
import code.src.interfaces.IForm;
import code.src.interfaces.ILogger;
import org.json.simple.parser.ParseException;

import java.io.IOException;

public class FormF1 implements IForm, ILogger {
    private static String apiLinkForFormInput;
    private static Initiator_F1 initiatorOfF1;

    public FormF1(String _apiLinkForFormInput)
    {
        setApiLinkForFormInput(_apiLinkForFormInput);
    }

    public static String getApiLinkForFormInput() {
        return apiLinkForFormInput;
    }

    public static void setApiLinkForFormInput(String apiLinkForFormInput) {
        FormF1.apiLinkForFormInput = apiLinkForFormInput;
    }

    @Override
    public void init() throws IOException, ParseException {
        initiatorOfF1 = new Initiator_F1(apiLinkForFormInput);
    }

    @Override
    public void pre_process() {
        logger.trace("Get keys from httpInput_F1 check for the sequence of fields ");
        logger.trace("Loop through the sequence and check for the validation specified for each field in form definition object");
        logger.trace("Call the validator multiple times ");
        logger.trace("Validator will have success hash inside it which will store result of each key ");
        logger.trace("It will have a result code, which maybe error or something");
        logger.trace("If the error is se to true it will look for error code key");
        logger.trace("If angular gets error code in response it will show error accordingly.");
    }

    @Override
    public void process() {

    }

    @Override
    public void post_process() {

    }
}
