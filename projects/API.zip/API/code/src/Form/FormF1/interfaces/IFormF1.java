package code.src.Form.FormF1.interfaces;

import code.src.interfaces.IForm;

public interface IFormF1 extends IForm {
}
