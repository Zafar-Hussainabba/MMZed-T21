package code.src.Form.FormF1;


import code.src.HttpInput.HttpInput;
import methods.ReusableMethods;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;

import java.io.IOException;

public class Test_FormF1 {
    private static final Logger logger = LogManager.getLogger( Test_FormF1.class );

    public static void main(String[] args) throws IOException, ParseException {
        ReusableMethods.configureLog4j("../../../../../conf/log4j", "log4j_API.properties");

        FormF1 formF1 = new FormF1("http://localhost:8080/FormInput");

        formF1.init();

        //HttpInput httpInput = new HttpInput();
        //logger.info(httpInput.isSingleKeyExist("__FORM_NAME__"));
    }


}
