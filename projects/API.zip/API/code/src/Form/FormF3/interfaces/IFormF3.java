package code.src.Form.FormF3.interfaces;

import code.src.interfaces.IForm;

public interface IFormF3 extends IForm {
}
