package code.src.HttpInput;

import Interfaces.ICommonHashmap;
import classes.SystemErrors;
import code.src.interfaces.ILogger;
import methods.ReusableMethods;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.util.HashMap;

public class HttpInput implements ICommonHashmap, ILogger {
    //private SystemErrors systemErrors = new SystemErrors();
    private HashMap<String, Object> httpInputHash = new HashMap<>();

    public HashMap<String, Object> getMap() {
        return null;
    }

    public void setMap(HashMap<String, Object> httpInputHash) {
        this.httpInputHash = httpInputHash;
    }

    public Boolean isSingleKeyExist(String key) {
        return httpInputHash.keySet().contains(key);
    }

    public HashMap<String, Boolean> isMultipleKeyExist(HashMap<String, String> keySetMap) {
        return ReusableMethods.isMultipleKeyExist(keySetMap,httpInputHash);
    }

    public String getSingleKey(String key)
    {
        //if (!isSingleKeyExist(key))
            //return systemErrors.getSingleKey("-1");
        return httpInputHash.get(key).toString();
    }

    public HashMap<String, Object> getMultipleKey(HashMap<String, String> keySetMap) {
        return null;
    }

    public void setSingleKey(String key, Object value) {

    }

    public void setMultipleKey(HashMap<String, Object> keySetMap) {

    }

    public void deleteSingleKey(String key) {

    }

    public void deleteMultipleKey(HashMap<String, String> keySetMap) {

    }

    public void updateSingleKey(String key, Object value) {

    }

    public void updateMultipleKey(HashMap<String, Object> keySetMap) {

    }
}
