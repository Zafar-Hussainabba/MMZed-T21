package code.src.interfaces;

import org.json.simple.parser.ParseException;

import java.io.IOException;

public interface IForm {
    void init() throws IOException, ParseException;
    void pre_process();
    void process();
    void post_process();
}
