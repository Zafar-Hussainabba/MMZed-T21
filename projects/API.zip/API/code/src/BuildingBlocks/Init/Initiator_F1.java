package code.src.BuildingBlocks.Init;

import FormValidator.Validator;
import code.src.ApiData.ApiData;
import code.src.HttpInput.HttpInput;
import code.src.Help.MMZed_HelpEngine;
import code.src.Validation.Validation_F1;
import code.src.interfaces.ILogger;
import org.json.simple.parser.ParseException;

import java.io.IOException;

public class Initiator_F1 implements ILogger {
    //private MMZed_ErrorEngine errorEngine = new MMZed_ErrorEngine();
    private MMZed_HelpEngine helpEngine_F1 = new MMZed_HelpEngine();
    private HttpInput httpInput_F1 = new HttpInput();
    private Validation_F1 validationData_F1 = new Validation_F1();
    private Validator validator_F1 = new Validator();
    private ApiData api = new ApiData();

    public Initiator_F1(String _apiLinkForFormInput) throws IOException, ParseException {
        httpInput_F1.setMap(api.get(_apiLinkForFormInput));
    }

    public void loader(String formName)
    {
        logger.trace("Load the specified forms error data ");
        logger.trace("Load the specified forms help data ");
        logger.trace("Load the validator for specified form ");
        logger.trace("Load the form definition data for specified form ");
    }
}
